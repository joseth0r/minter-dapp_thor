# Mobile Planet gallery

A Pen created on CodePen.io. Original URL: [https://codepen.io/simoberny/pen/aqjEbz](https://codepen.io/simoberny/pen/aqjEbz).

Ispiration: https://www.uplabs.com/posts/xore-solar-system
Full site: simoberny.it
Best on mobile

Library: Anime.js, Hammer.js